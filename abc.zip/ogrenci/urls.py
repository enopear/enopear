from django.urls import path
from . import views

urlpatterns = [
    path('ogrenci/', views.ogrenci, name='ogrenci'),
    path('student/', views.ogrenci, name='ogrenci'),
]
