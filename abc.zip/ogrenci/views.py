from django.http import HttpResponse
from django.template import loader
from django import forms
from .models import Ogrenci
from django.shortcuts import redirect
from django.shortcuts import render



def ogrenci(request):
  template = loader.get_template('anma.html')
  return HttpResponse(template.render())



class OgrenciForm(forms.ModelForm):
    class Meta:
        model = Ogrenci
        fields = ['TC', 'AdiSoyadi',
                  'Aciklama']  
# Kullanmak istediğiniz alanları buraya ekleyin

def ekle(request):
    if request.method == 'POST':
        form = OgrenciForm(request.POST)
        if form.is_valid():
            # Form verileri işleme
            form.save()  # Veritabanına kaydetme
            return redirect('ogrenci')  #url name

    else:
        form = OgrenciForm()
    return render(request, 'ana.html', {'form': form})
  