from django.http import HttpResponse
from django.template import loader

def ogretmen(request):
  template = loader.get_template('anama.html')
  return HttpResponse(template.render())