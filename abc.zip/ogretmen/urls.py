from django.urls import path
from . import views

urlpatterns = [
    path('ogretmen/', views.ogretmen, name='ogretmen'),
    path('teacher/', views.ogretmen, name='ogretmen'),
]

